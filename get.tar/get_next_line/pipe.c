/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipe.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jhakala <jhakala@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/06 12:45:41 by jhakala           #+#    #+#             */
/*   Updated: 2019/11/06 12:49:04 by jhakala          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int main(void)
{
	printf("The Academy of Athens is Greece's national academy and the highest research\n");
	printf("establishment in the country. Established on 18 March 1926, it operates under the\n");
	printf("supervision of the Ministry of Education and Religious Affairs.\n");
	return (0);
}
