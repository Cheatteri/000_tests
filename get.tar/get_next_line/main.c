/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jhakala <jhakala@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/11/05 14:31:04 by jhakala           #+#    #+#             */
/*   Updated: 2019/11/30 17:02:08 by jhakala          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <fcntl.h>
#include <stdio.h>

/*
get_next_line(fd, &line)
printf("%s\n", line)
*/


int	main(int ac, char **av)
{
	char	*line;
	int		fd;
	int		i;
	int		j;

	j = 1;
	i = 0;

	if (ac > 1)
	{
		while (ac > j)
		{
			fd = open(av[j], O_RDONLY);
			printf("%d\n", fd);
			while ((i = get_next_line(fd, &line)) > 0)
			{
				printf("%d:	", i);
				printf("%s\n", line);
				free(line);
			}
			printf("%d:	\n", i);
			j++;
			if (ac > j)
				printf("\n");
		}
	}
	else
	{
		while ((i = get_next_line(0, &line)) > 0)
		{
			printf("%d:	", i);
			printf("%s\n", line);
		}
		printf("%d:	\n", i);
	}
	return (0);
}

/*
int	main(int ac, char **av)
{
	int		fd1;
	int		fd2;
	int		fd3;
	char	*line;

	fd1 = open(av[1], O_RDONLY);
	fd2 = open(av[2], O_RDONLY);
	fd3 = open(av[3], O_RDONLY);
	printf("%d\n%d\n%d\n", fd1, fd2, fd3);
	if (ac > 1)
	{
		get_next_line(fd2, &line);
		printf("%s\n", line);
		get_next_line(fd1, &line);
		get_next_line(fd1, &line);
		get_next_line(fd2, &line);
		get_next_line(fd1, &line);
		printf("%s\n", line);
	}
	return (0);
}
*/
