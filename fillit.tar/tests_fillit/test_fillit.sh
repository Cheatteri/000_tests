./fillit tests_fillit/wrong1
./fillit tests_fillit/wrong2
./fillit tests_fillit/wrong2_1
./fillit tests_fillit/wrong3
./fillit tests_fillit/wrong4
./fillit tests_fillit/wrong5
./fillit tests_fillit/wrong6toomany
echo 7 errors?
echo 
./fillit tests_fillit/right1
echo 
./fillit tests_fillit/right2
echo 
./fillit tests_fillit/right3
echo 
./fillit tests_fillit/right4
echo 
./fillit tests_fillit/right5
echo 
./fillit tests_fillit/right6_26
echo 
echo 6 corrects?