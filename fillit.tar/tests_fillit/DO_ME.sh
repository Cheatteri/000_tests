echo -e "\033[0;32mfirst	bash test_fillit.sh\033[0m"
echo -e "\033[0;32mthen	bash test_fillit2.sh\033[0m"
echo -e "\033[0;32mthen	./fillit test_fillit/test11\033[0m"
echo -e "\033[0;32mthen	./fillit test_fillit/dif\033[0m"
cp test_fillit.sh ../
cp test_fillit2.sh ../