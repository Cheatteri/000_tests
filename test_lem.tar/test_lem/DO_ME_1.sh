echo "--------------------------------------empty file"
./../lem-in < wrong_maps/empty_file
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------bad end"
./../lem-in < wrong_maps/err_bad_end.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------bad end 2"
./../lem-in < wrong_maps/err_bad_end2.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------bad start"
./../lem-in < wrong_maps/err_bad_start.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------bad start 2"
./../lem-in < wrong_maps/err_bad_start2.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------start is end"
./../lem-in < wrong_maps/err_start_is_end.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------room defined after link"
./../lem-in < wrong_maps/err_part2_before_part1.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------duplicate start"
./../lem-in < wrong_maps/err_double_start.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------duplicate end"
./../lem-in < wrong_maps/err_double_end.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------double link"
./../lem-in < wrong_maps/err_double_link.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------double room name"
./../lem-in < wrong_maps/err_double_room_name.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------empty map"
./../lem-in < wrong_maps/err_empty_map.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------letter in ants"
./../lem-in < wrong_maps/err_letter_in_ants.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------letter in coord"
./../lem-in < wrong_maps/err_letter_in_coords.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------negative ant nb"
./../lem-in < wrong_maps/err_neg_ants.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------no end"
./../lem-in < wrong_maps/err_no_end.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------no link"
./../lem-in < wrong_maps/err_no_link.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------no rooms"
./../lem-in < wrong_maps/err_no_rooms.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------no start"
./../lem-in < wrong_maps/err_no_start.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------link unknown room"
./../lem-in < wrong_maps/err_link_unknown_room.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------start is end"
./../lem-in < wrong_maps/err_start_end.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------too few ants"
./../lem-in < wrong_maps/err_too_few_ants.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------too many ants"
./../lem-in < wrong_maps/err_too_many_ants.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------duplicate room"
./../lem-in < wrong_maps/err_duplicate.txt
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
echo "--------------------------------------no path"
./../lem-in < wrong_maps/err_no_path.txt
echo "---------------------------------------------"