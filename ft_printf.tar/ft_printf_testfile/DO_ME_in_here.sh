cp test.sh ../
cp main.c ../
cp write_main.c ../
cd ..
bash test.sh