make re
gcc -Wall -Wextra -Werror main.c -I includes libftprintf.a
gcc -o tes write_main.c -I includes libftprintf.a
echo -e "show print? \033[1;32m-->[y/n]<--\033[0m"
read varyn
if [ $varyn == "y" ]; then
	./a.out
fi
./tes
echo "-->diff user_file mo_file<--"
diff user_file mo_file
echo -e "show files? \033[1;32m-->[y/n]<--\033[0m"
read varyn
if [ $varyn == "y" ]; then
	cat user_file
	read varyn
	cat mo_file
fi
echo -e "clean? \033[1;32m-->[y/n]<--\033[0m"
read varyn
if [ $varyn == "y" ]; then
	rm -rf user_file
	rm -rf mo_file
	rm -rf tes
	rm -rf a.out
	rm -rf main.c
	rm -rf write_main.c
	rm -rf test.sh
fi