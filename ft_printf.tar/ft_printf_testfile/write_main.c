/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   write_main.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jhakala <jhakala@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/01/08 10:46:40 by jhakala           #+#    #+#             */
/*   Updated: 2020/01/08 11:46:48 by jhakala          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
#include <stdio.h>
#include <fcntl.h>

//  green:  \033[1;32m
//  red:    \033[1;31m
//  blue:   \033[1;34m
//  yellow: \033[1;33m
//  reset:  \033[0m

int main(void)
{
    double              a;
    long double         b;
    long int            c;
    unsigned long long  d;
    int                 x, z;

    a = -42.0045009096905;
    b = (long double)a;
	x = 0;
	char *name = "user_file";
    int fd = open(name, O_WRONLY | O_CREAT, 0644);
    dup2(fd, 1);
    x += ft_printf("1'%.12f'\n", a);
	x += ft_printf("2'%.15f'\n", a);
	x += ft_printf("3'%012f'\n", a);
	x += ft_printf("4'%+f'\n", a);
	x += ft_printf("5'%Lf'\n", b);
	b = 0;
	x += ft_printf("6'%#.0Lf'\n", b);
	x += ft_printf("7'%.10f'\n", -875.000001);
	x += ft_printf("8'%f'\n", 3.9999999);
	x += ft_printf("9'%f'\n", 10.9999996);
	x += ft_printf("10'%5.0f'\n", -7.3);
	x += ft_printf("11'%.0f'\n", (double)-7.32123);
	x += ft_printf("12'% 12d'\n", -1);
	x += ft_printf("13'%.0d'\n", 0);
	x += ft_printf("14'%-12d'\n", -1);
	x += ft_printf("15'%%'\n");
	x += ft_printf("16'%.0i'\n", 1);
	c = 124;
	x += ft_printf("17'%ld'\n", c);
	x += ft_printf("18'%.d %.0d'\n", 0, 0);
	x += ft_printf("19'{%.*d}'\n", -5, 42);
	x += ft_printf("20'{%05.*d}'\n", -15, 42);
	x += ft_printf("21'%010.5i'\n", -216);
	x += ft_printf("22'%08.3i'\n", -8473);
	x += ft_printf("23'%07i'\n", -54);
	x += ft_printf("24'%+.0i'\n", 0);
	c = 123;
    x += ft_printf("25'%lx'\n", c);
	x += ft_printf("26'%x'\n", 0);
	x += ft_printf("27'%lx'\n", 4294967296);
	x += ft_printf("28'%010x'\n", 542);
	x += ft_printf("29'%-10x'\n", 543);
	d = 9223372036854775807;
    x += ft_printf("30'%#llx'\n", d);
	x += ft_printf("31'%#-8x'\n", 42);
	x += ft_printf("32'%#08x'\n", 42);
	x += ft_printf("33'%#-7X'\n", 52625);
	x += ft_printf("34'%#-7x'\n", 52625);
	x += ft_printf("35'{%#.5x}'\n", 1);
	x += ft_printf("36'%o'\n", 0);
	x += ft_printf("37'%.10o'\n", 2);
	x += ft_printf("38' %.o %.0o'\n", 0, 0);
	x += ft_printf("39'%.o'\n", 0);
	x += ft_printf("40'%#.o %#.0o'\n", 0, 0);
	x += ft_printf("41'%#6o'\n", 2500);
	x += ft_printf("42'%#o'\n", 2500);
	x += ft_printf("43'%-#6o'\n", 2500);
	x += ft_printf("44'%-#5o'\n", 2500);
	x += ft_printf("45'%#.20o'\n", 123456);
	x += ft_printf("46'%#.3o'\n", 1);
	x += ft_printf("47'%05o'\n", 2500);
	x += ft_printf("48'%#o'\n", 0);
	x += ft_printf("49'%#3o'\n", 0);
	x += ft_printf("50'%.0s'\n","mo");
	x += ft_printf("51'%.s'\n", "hi low");
	x += ft_printf("52'%.19s'\n", "hi low");
	x += ft_printf("53'{%.*s}'\n", -5, "42");
	x += ft_printf("54'%-5.2s is a string'\n", "this");
	x += ft_printf("55'%-10s'\n", NULL);
	x += ft_printf("56'%.09s'\n", "hi low");
	x += ft_printf("57'%.01s'\n","mo");
	x += ft_printf("58'%-8.5u'\n", 34);
	x += ft_printf("59'%8.5u'\n", 34);
	x += ft_printf("60'%-5.0u'\n", 0);
	x += ft_printf("61'%-5.0u'\n", 1);
	x += ft_printf("62'%-8.5u'\n", 0);

	ft_printf("'value: %d'\n", x);

    a = -42.0045009096905;
    b = (long double)a;
    name = "mo_file";
    fd = open(name, O_WRONLY | O_CREAT, 0644);
    dup2(fd, 1);
	x = 0;
    x += printf("1'%.12f'\n", a);
	x += printf("2'%.15f'\n", a);
	x += printf("3'%012f'\n", a);
	x += printf("4'%+f'\n", a);
	x += printf("5'%Lf'\n", b);
	b = 0;
	x += printf("6'%#.0Lf'\n", b);
	x += printf("7'%.10f'\n", -875.000001);
	x += printf("8'%f'\n", 3.9999999);
	x += printf("9'%f'\n", 10.9999996);
	x += printf("10'%5.0f'\n", -7.3);
	x += printf("11'%.0f'\n", (double)-7.32123);
	x += printf("12'% 12d'\n", -1);
	x += printf("13'%.0d'\n", 0);
	x += printf("14'%-12d'\n", -1);
	x += printf("15'%%'\n");
	x += printf("16'%.0i'\n", 1);
	c = 124;
	x += printf("17'%ld'\n", c);
	x += printf("18'%.d %.0d'\n", 0, 0);
	x += printf("19'{%.*d}'\n", -5, 42);
	x += printf("20'{%05.*d}'\n", -15, 42);
	x += printf("21'%010.5i'\n", -216);
	x += printf("22'%08.3i'\n", -8473);
	x += printf("23'%07i'\n", -54);
	x += printf("24'%+.0i'\n", 0);
	c = 123;
    x += printf("25'%lx'\n", c);
	x += printf("26'%x'\n", 0);
	x += printf("27'%lx'\n", 4294967296);
	x += printf("28'%010x'\n", 542);
	x += printf("29'%-10x'\n", 543);
	d = 9223372036854775807;
    x += printf("30'%#llx'\n", d);
	x += printf("31'%#-8x'\n", 42);
	x += printf("32'%#08x'\n", 42);
	x += printf("33'%#-7X'\n", 52625);
	x += printf("34'%#-7x'\n", 52625);
	x += printf("35'{%#.5x}'\n", 1);
	x += printf("36'%o'\n", 0);
	x += printf("37'%.10o'\n", 2);
	x += printf("38' %.o %.0o'\n", 0, 0);
	x += printf("39'%.o'\n", 0);
	x += printf("40'%#.o %#.0o'\n", 0, 0);
	x += printf("41'%#6o'\n", 2500);
	x += printf("42'%#o'\n", 2500);
	x += printf("43'%-#6o'\n", 2500);
	x += printf("44'%-#5o'\n", 2500);
	x += printf("45'%#.20o'\n", 123456);
	x += printf("46'%#.3o'\n", 1);
	x += printf("47'%05o'\n", 2500);
	x += printf("48'%#o'\n", 0);
	x += printf("49'%#3o'\n", 0);
	x += printf("50'%.0s'\n","mo");
	x += printf("51'%.s'\n", "hi low");
	x += printf("52'%.19s'\n", "hi low");
	x += printf("53'{%.*s}'\n", -5, "42");
	x += printf("54'%-5.2s is a string'\n", "this");
	x += printf("55'%-10s'\n", NULL);
	x += printf("56'%.09s'\n", "hi low");
	x += printf("57'%.01s'\n","mo");
	x += printf("58'%-8.5u'\n", 34);
	x += printf("59'%8.5u'\n", 34);
	x += printf("60'%-5.0u'\n", 0);
	x += printf("61'%-5.0u'\n", 1);
	x += printf("62'%-8.5u'\n", 0);

	printf("'value: %d'\n", x);
	return (0);
}
