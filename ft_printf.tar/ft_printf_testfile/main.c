/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jhakala <jhakala@student.hive.fi>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/12/12 00:29:45 by jhakala           #+#    #+#             */
/*   Updated: 2020/01/08 11:49:18 by jhakala          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"
#include <stdio.h>

//	green:	\033[1;32m
//	red:	\033[1;31m
//	blue:	\033[1;34m
//	yellow:	\033[1;33m
//	reset:	\033[0m

int	main(void)
{
	double				a;
	long double			b;
	long int			c;
	unsigned long long	d;
	int					x, z;
	int h, j;

	h = 0;
	j = 0;
	a = -42.0045009096905;
	b = (long double)a;
	printf("\n\033[1;33mStart\033[0m\n");

	x = ft_printf("'%#.2f%012djotain vali%.1stekstia %%%s%% %%%i'", a, 12, " s", "valissaa", -0);
	printf("\n");
	z = printf("'%#.2f%012djotain vali%.1stekstia %%%s%% %%%i'", a, 12, " s", "valissaa", -0);
	j += x;
	h += z;
	x == z ? printf("\nmy: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m0,f\033[0m\n");
//	0f
	x = ft_printf("'%.12f'\n", a);
	z = printf("'%.12f'\n", a);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.15f'\n", a);
	z = printf("'%.15f'\n", a);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%012f'\n", a);
	z = printf("'%012f'\n", a);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%+f'\n", a);
	z = printf("'%+f'\n", a);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%Lf'\n", b);
	z = printf("'%Lf'\n", b);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	b = 0;
	x = ft_printf("'%#.0Lf'\n", b);
	z = printf("'%#.0Lf'\n", b);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m0,5f\033[0m\n");
//	0,5f
	x = ft_printf("'%.10f'\n", -875.000001);
	z = printf("'%.10f'\n", -875.000001);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%f'\n", 3.9999999);
	z = printf("'%f'\n", 3.9999999);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%f'\n", 10.9999996);
	z = printf("'%f'\n", 10.9999996);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%5.0f'\n", -7.3);
	z = printf("'%5.0f'\n", -7.3);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.0f'\n", (double)-7.32123);
	z = printf("'%.0f'\n", (double)-7.32);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m1,d,i\033[0m\n");
//	1di
	x = ft_printf("'% 12d'\n", -1);
	z = printf("'% 12d'\n", -1);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.0d'\n", 0);
	z = printf("'%.0d'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-12d'\n", -1);
	z = printf("'%-12d'\n", -1);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%%'\n");
	z = printf("'%%'\n");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.0i'\n", 1);
	z = printf("'%.0i'\n", 1);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	c = 124;
	x = ft_printf("'%ld'\n", c);
	z = printf("'%ld'\n", c);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.d %.0d'\n", 0, 0);
	z = printf("'%.d %.0d'\n", 0, 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'{%.*d}'\n", -5, 42);
	z = printf("'{%.*d}'\n", -5, 42);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'{%05.*d}'\n", -15, 42);
	z = printf("'{%05.*d}'\n", -15, 42);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m5,d,i again?\033[0m\n");
//	1,5,d,i again?

	x = ft_printf("'%010.5i'\n", -216);
	z = printf("'%010.5i'\n", -216);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%08.3i'\n", -8473);
	z = printf("'%08.3i'\n", -8473);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%07i'\n", -54);
	z = printf("'%07i'\n", -54);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%+.0i'\n", 0);
	z = printf("'%+.0i'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m2,x?\033[0m\n");
//	2,x?
	c = 123;
	x = ft_printf("'%lx'\n", c);
	z = printf("'%lx'\n", c);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%x'\n", 0);
	z = printf("'%x'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%lx'\n", 4294967296);
	z = printf("'%lx'\n", 4294967296);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#-7x'\n", 52625);
	z = printf("'%#-7x'\n", 542);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-10x'\n", 543);
	z = printf("'%-10x'\n", 543);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	d = 9223372036854775807;
	x = ft_printf("'%#llx'\n", d);
	z = printf("'%#llx'\n", d);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#-8x'\n", 42);
	z = printf("'%#-8x'\n", 42);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#08x'\n", 42);
	z = printf("'%#08x'\n", 42);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m2,5x?\033[0m\n");
//	2,5x?
	x = ft_printf("'%#-7X'\n", 52625);
	z = printf("'%#-7X'\n", 52625);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#-7x'\n", 52625);
	z = printf("'%#-7x'\n", 52625);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'{%#.5x}'\n", 1);
	z = printf("'{%#.5x}'\n", 1);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m3,o\033[0m\n");

//	3,o
	x = ft_printf("'%o'\n", 0);
	z = printf("'%o'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.10o'\n", 2);
	z = printf("'%.10o'\n", 2);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("' %.o %.0o'\n", 0, 0);
	z = printf("' %.o %.0o'\n", 0, 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.o'\n", 0);
	z = printf("'%.o'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#.o %#.0o'\n", 0, 0);
	z = printf("'%#.o %#.0o'\n", 0, 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#6o'\n", 2500);
	z = printf("'%#6o'\n", 2500);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#o'\n", 2500);
	z = printf("'%#o'\n", 2500);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m3,5\033[0m\n");
//	3,5
	x = ft_printf("'%-#6o'\n", 2500);
	z = printf("'%-#6o'\n", 2500);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-#5o'\n", 2500);
	z = printf("'%-#5o'\n", 2500);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#.20o'\n", 123456);
	z = printf("'%#.20o'\n", 123456);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#.3o'\n", 1);
	z = printf("'%#.3o'\n", 1);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%05o'\n", 2500);
	z = printf("'%05o'\n", 2500);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#o'\n", 0);
	z = printf("'%#o'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%#3o'\n", 0);
	z = printf("'%#3o'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m4,s?\033[0m\n");
//	4,s?

	x = ft_printf("'%.0s'\n","mo");
	z = printf("'%.0s'\n", "mo");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.s'\n", "hi low");
	z = printf("'%.s'\n", "hi low");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.19s'\n", "hi low");
	z = printf("'%.19s'\n", "hi low");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'{%.*s}'\n", -5, "42");
	z = printf("'{%.*s}'\n", -5, "42");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-5.2s is a string'\n", "this");
	z = printf("'%-5.2s is a string'\n", "this");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-10s'\n", NULL);
	z = printf("'%-10s'\n", NULL);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.09s'\n", "hi low");
	z = printf("'%.09s'\n", "hi low");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%.01s'\n","mo");
	z = printf("'%.01s'\n","mo");
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	printf("\n\033[1;34m5,u\033[0m\n");
//	5,u

	x = ft_printf("'%-8.5u'\n", 34);
	z = printf("'%-8.5u'\n", 34);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%8.5u'\n", 34);
	z = printf("'%8.5u'\n", 34);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-5.0u'\n", 0);
	z = printf("'%-5.0u'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-5.0u'\n", 1);
	z = printf("'%-5.0u'\n", 1);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);
	x = ft_printf("'%-8.5u'\n", 0);
	z = printf("'%-8.5u'\n", 0);
	j += x;
	h += z;
	x == z ? printf("my: \033[1;32m%d\033[0m == they: \033[1;32m%d\033[0m\n", x, z) : printf("my: \033[1;31m%d\033[0m == they: \033[1;31m%d\033[0m\n", x, z);

	h == j ? printf("return value : \033[0;32m[OK]\033[0m\n") : printf("return value : \033[0;31m[KO]\033[0m\n");
//	while (1){}
	return (0);
}
